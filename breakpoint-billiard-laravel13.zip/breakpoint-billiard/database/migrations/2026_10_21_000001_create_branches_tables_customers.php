<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('branches', function (Blueprint $table) {
            $table->id(); $table->string('name'); $table->string('slug')->unique(); $table->string('address');
            $table->string('phone', 30)->nullable(); $table->time('opens_at')->default('10:00'); $table->time('closes_at')->default('23:00');
            $table->boolean('is_active')->default(true); $table->timestamps();
        });
        Schema::create('billiard_tables', function (Blueprint $table) {
            $table->id(); $table->foreignId('branch_id')->constrained()->cascadeOnDelete();
            $table->string('name'); $table->string('table_type')->default('Standard'); $table->unsignedInteger('hourly_rate')->default(50000);
            $table->boolean('is_active')->default(true); $table->text('notes')->nullable(); $table->timestamps();
            $table->unique(['branch_id', 'name']);
        });
        Schema::create('customers', function (Blueprint $table) {
            $table->id(); $table->string('name'); $table->string('phone', 30)->unique(); $table->string('email')->nullable(); $table->timestamps();
        });
    }
    public function down(): void {
        Schema::dropIfExists('customers'); Schema::dropIfExists('billiard_tables'); Schema::dropIfExists('branches');
    }
};
