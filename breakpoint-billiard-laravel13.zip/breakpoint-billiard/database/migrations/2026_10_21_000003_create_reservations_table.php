<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('reservations', function (Blueprint $table) {
            $table->id(); $table->string('code')->unique();
            $table->foreignId('branch_id')->constrained()->restrictOnDelete();
            $table->foreignId('table_id')->constrained('billiard_tables')->restrictOnDelete();
            $table->foreignId('customer_id')->constrained()->restrictOnDelete();
            $table->timestampTz('starts_at'); $table->timestampTz('ends_at');
            $table->unsignedSmallInteger('duration_minutes'); $table->unsignedInteger('hourly_rate'); $table->unsignedInteger('total_amount');
            $table->string('status')->default('confirmed'); $table->string('payment_status')->default('unpaid');
            $table->text('notes')->nullable(); $table->timestampTz('checked_in_at')->nullable(); $table->timestampTz('cancelled_at')->nullable();
            $table->timestamps();
            $table->index(['table_id', 'starts_at', 'ends_at']);
            $table->index(['branch_id', 'starts_at']);
            $table->index(['status', 'payment_status']);
        });
    }
    public function down(): void { Schema::dropIfExists('reservations'); }
};
