<?php

namespace Database\Seeders;

use App\Models\Branch;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $branch = Branch::firstOrCreate(['slug' => 'jakarta-selatan'], [
            'name' => 'BreakPoint Jakarta Selatan',
            'address' => 'Alamat cabang contoh — ubah melalui database sebelum dipakai',
            'phone' => '02100000000',
            'opens_at' => '10:00',
            'closes_at' => '23:00',
            'is_active' => true,
        ]);

        for ($i = 1; $i <= 9; $i++) {
            $branch->tables()->firstOrCreate(['name' => 'Meja '.str_pad((string)$i, 2, '0', STR_PAD_LEFT)], [
                'table_type' => 'Standard', 'hourly_rate' => 50000, 'is_active' => true,
            ]);
        }
    }
}
