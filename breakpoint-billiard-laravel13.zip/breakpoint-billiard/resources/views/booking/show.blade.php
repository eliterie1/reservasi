@extends('layouts.app')
@section('title', 'Detail Reservasi '.$reservation->code)
@section('content')
<div class="mx-auto max-w-2xl px-4 py-14">
  <div class="rounded-3xl border border-slate-200 bg-white p-6 text-center shadow-sm sm:p-10">
    <div class="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-50 text-3xl text-emerald-800">✓</div>
    <p class="mt-5 text-xs font-bold uppercase tracking-[.2em] text-emerald-800">Booking confirmed</p>
    <h1 class="mt-2 text-3xl font-extrabold">Reservasi berhasil!</h1>
    <p class="mt-3 text-slate-600">Tunjukkan kode ini kepada kasir saat tiba di cabang.</p>
    <div class="mt-6 rounded-2xl bg-slate-50 p-5"><p class="text-xs uppercase tracking-wider text-slate-500">Kode reservasi</p><p class="mt-2 text-2xl font-extrabold tracking-widest brand">{{ $reservation->code }}</p></div>
    <div class="mt-6 space-y-3 text-left">
      @foreach([['Cabang',$reservation->branch->name],['Alamat',$reservation->branch->address],['Meja',$reservation->table->name],['Pemesan',$reservation->customer->name],['Tanggal',$reservation->starts_at->timezone('Asia/Jakarta')->format('d M Y')],['Waktu',$reservation->starts_at->timezone('Asia/Jakarta')->format('H:i').' – '.$reservation->ends_at->timezone('Asia/Jakarta')->format('H:i')],['Durasi',$reservation->duration_minutes.' menit'],['Total','Rp'.number_format($reservation->total_amount,0,',','.')],['Pembayaran','Bayar di lokasi · Belum dibayar']] as $item)
      <div class="flex justify-between gap-4 border-b border-slate-100 py-2 text-sm"><span class="text-slate-500">{{ $item[0] }}</span><span class="text-right font-semibold">{{ $item[1] }}</span></div>
      @endforeach
    </div>
    <p class="mt-5 text-sm text-slate-500">Simpan halaman atau catat kode booking Anda. Pembayaran dilakukan di kasir.</p>
    <a href="{{ route('home') }}" class="mt-6 inline-flex rounded-xl bg-brand px-5 py-3 font-semibold text-white">Kembali ke beranda</a>
  </div>
</div>
@endsection
