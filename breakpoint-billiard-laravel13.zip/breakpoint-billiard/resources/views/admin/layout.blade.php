@extends('layouts.app')
@section('content')
<div class="mx-auto max-w-6xl px-4 py-8">
  <div class="flex flex-wrap items-center justify-between gap-4"><div><p class="text-xs font-bold uppercase tracking-[.2em] text-emerald-800">Management console</p><h1 class="mt-1 text-3xl font-extrabold">@yield('heading', 'Dashboard')</h1></div><div class="flex flex-wrap gap-2 text-sm"><a href="{{ route('admin.index') }}" class="rounded-lg border px-3 py-2">Ringkasan</a><a href="{{ route('admin.reservations') }}" class="rounded-lg border px-3 py-2">Reservasi</a><a href="{{ route('admin.tables') }}" class="rounded-lg border px-3 py-2">Meja & tarif</a>@if(auth()->user()->isOwner())<a href="{{ route('admin.branches') }}" class="rounded-lg border px-3 py-2">Cabang</a>@endif</div></div>
  <div class="mt-7">@yield('admin_content')</div>
</div>
@endsection
