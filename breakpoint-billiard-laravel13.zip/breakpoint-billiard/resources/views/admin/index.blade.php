@extends('admin.layout')
@section('title','Dashboard Admin')
@section('heading','Ringkasan operasional')
@section('admin_content')
<div class="grid gap-4 sm:grid-cols-3">
  <div class="rounded-2xl border p-5"><p class="text-sm text-slate-500">Reservasi hari ini</p><p class="mt-2 text-3xl font-extrabold">{{ $stats['today'] }}</p></div>
  <div class="rounded-2xl border p-5"><p class="text-sm text-slate-500">Sedang bermain</p><p class="mt-2 text-3xl font-extrabold">{{ $stats['playing'] }}</p></div>
  <div class="rounded-2xl border p-5"><p class="text-sm text-slate-500">Tagihan belum lunas</p><p class="mt-2 text-2xl font-extrabold">Rp{{ number_format($stats['unpaid'],0,',','.') }}</p></div>
</div>
@if(auth()->user()->isOwner())
<section class="mt-8"><h2 class="text-lg font-bold">Cabang</h2><div class="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">@foreach($branches as $branch)<div class="rounded-2xl border p-4"><h3 class="font-bold">{{ $branch->name }}</h3><p class="mt-1 text-sm text-slate-500">{{ $branch->address }}</p><p class="mt-3 text-sm">{{ $branch->tables_count }} meja · {{ substr($branch->opens_at,0,5) }}–{{ substr($branch->closes_at,0,5) }}</p></div>@endforeach</div></section>
@endif
<section class="mt-8"><div class="flex items-center justify-between"><h2 class="text-lg font-bold">Reservasi hari ini</h2><a href="{{ route('admin.reservations') }}" class="text-sm font-semibold brand">Lihat semua →</a></div>
<div class="mt-3 overflow-x-auto rounded-2xl border"><table class="w-full min-w-[720px] text-left text-sm"><thead class="bg-slate-50 text-slate-500"><tr><th class="px-4 py-3">Kode</th><th class="px-4 py-3">Pelanggan</th><th class="px-4 py-3">Meja / cabang</th><th class="px-4 py-3">Waktu</th><th class="px-4 py-3">Status</th></tr></thead><tbody class="divide-y">@forelse($reservations as $r)<tr><td class="px-4 py-3 font-semibold">{{ $r->code }}</td><td class="px-4 py-3">{{ $r->customer->name }}<p class="text-xs text-slate-500">{{ $r->customer->phone }}</p></td><td class="px-4 py-3">{{ $r->table->name }}<p class="text-xs text-slate-500">{{ $r->branch->name }}</p></td><td class="px-4 py-3">{{ $r->starts_at->format('H:i') }}–{{ $r->ends_at->format('H:i') }}</td><td class="px-4 py-3">{{ ucfirst($r->status) }}</td></tr>@empty<tr><td colspan="5" class="px-4 py-8 text-center text-slate-500">Belum ada reservasi hari ini.</td></tr>@endforelse</tbody></table></div></section>
@endsection
