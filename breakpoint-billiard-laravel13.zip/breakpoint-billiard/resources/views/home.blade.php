@extends('layouts.app')
@section('title', 'Reservasi Meja Biliar | BreakPoint')
@section('content')
<section class="mx-auto grid max-w-6xl items-center gap-10 px-4 py-12 md:grid-cols-2 md:py-20">
  <div>
    <p class="mb-4 text-xs font-bold uppercase tracking-[.25em] text-emerald-800">Your next game starts here</p>
    <h1 class="max-w-xl text-4xl font-extrabold leading-tight tracking-tight text-slate-950 sm:text-6xl">Waktunya main.<br><span class="brand">Mejanya tinggal pilih.</span></h1>
    <p class="mt-5 max-w-lg leading-7 text-slate-600">Pilih cabang, tentukan waktu bermain, dan amankan meja biliar favoritmu. Pembayaran dilakukan langsung di lokasi.</p>
    <div class="mt-8 flex flex-wrap gap-3"><a href="{{ route('booking.create') }}" class="rounded-xl bg-brand px-5 py-3 font-semibold text-white shadow-sm hover:bg-emerald-950">Reservasi meja <span aria-hidden="true">→</span></a><a href="#cabang" class="rounded-xl border border-slate-200 px-5 py-3 font-semibold text-slate-700 hover:bg-slate-50">Lihat cabang</a></div>
    <div class="mt-9 flex flex-wrap gap-5 text-sm text-slate-600"><span>✓ Booking langsung</span><span>✓ Tanpa pembayaran online</span><span>✓ Pilih cabang</span></div>
  </div>
  <div class="relative">
    <div class="absolute -inset-3 rounded-[2rem] bg-emerald-50"></div>
    <div class="relative overflow-hidden rounded-[1.6rem] bg-emerald-950 p-6 sm:p-8">
      <div class="mb-6 flex items-center justify-between text-white"><span class="text-sm font-semibold">Pilih meja. Atur permainan.</span><span class="rounded-full bg-white/10 px-3 py-1 text-xs">BOOK ONLINE</span></div>
      <div class="rounded-2xl border-[10px] border-amber-900 bg-emerald-700 p-3 shadow-2xl">
        <div class="flex aspect-[1.45/1] items-center justify-center rounded border border-white/30">
          <div class="relative flex h-20 w-20 items-center justify-center rounded-full border border-white/30 text-2xl text-white/80">8
            <span class="absolute -right-8 -top-2 h-5 w-5 rounded-full bg-white shadow"></span><span class="absolute -left-7 bottom-0 h-5 w-5 rounded-full bg-amber-300 shadow"></span><span class="absolute -bottom-5 right-0 h-5 w-5 rounded-full bg-rose-400 shadow"></span>
          </div>
        </div>
      </div>
      <div class="mt-6 grid grid-cols-3 gap-3 text-center text-white"><div class="rounded-xl bg-white/10 p-3"><p class="text-xl font-bold">01</p><p class="mt-1 text-xs text-white/70">Pilih cabang</p></div><div class="rounded-xl bg-white/10 p-3"><p class="text-xl font-bold">02</p><p class="mt-1 text-xs text-white/70">Pilih waktu</p></div><div class="rounded-xl bg-white/10 p-3"><p class="text-xl font-bold">03</p><p class="mt-1 text-xs text-white/70">Konfirmasi</p></div></div>
    </div>
  </div>
</section>
<section id="cabang" class="bg-slate-50 py-14"><div class="mx-auto max-w-6xl px-4">
  <div class="mb-7 flex flex-wrap items-end justify-between gap-3"><div><p class="text-xs font-bold uppercase tracking-[.2em] text-emerald-800">Temukan lokasi</p><h2 class="mt-2 text-2xl font-bold tracking-tight">Pilih cabang favoritmu</h2></div><a class="text-sm font-semibold brand" href="{{ route('booking.create') }}">Lihat semua jadwal →</a></div>
  @if($branches->isEmpty())
    <div class="rounded-2xl border border-dashed border-slate-300 bg-white p-8 text-center"><h3 class="font-semibold">Cabang segera hadir</h3><p class="mt-2 text-sm text-slate-500">Belum ada cabang aktif. Admin dapat menambah cabang melalui dashboard.</p></div>
  @else
    <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">@foreach($branches as $branch)
      <article class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><div class="flex items-start justify-between gap-3"><div><h3 class="font-bold">{{ $branch->name }}</h3><p class="mt-2 text-sm leading-6 text-slate-500">{{ $branch->address }}</p></div><span class="rounded-lg bg-emerald-50 px-2 py-1 text-xs font-semibold text-emerald-800">{{ $branch->tables_count }} meja</span></div><div class="mt-5 flex items-center justify-between border-t border-slate-100 pt-4"><span class="text-sm text-slate-500">Mulai Rp50.000/jam*</span><a href="{{ route('booking.create', ['branch_id' => $branch->id]) }}" class="rounded-lg bg-brand px-3 py-2 text-sm font-semibold text-white">Pilih cabang</a></div></article>
    @endforeach</div>
  @endif
  <p class="mt-4 text-xs text-slate-400">*Tarif ditampilkan sebagai contoh; harga aktual mengikuti tarif meja pada cabang yang dipilih.</p>
</div></section>
@endsection
