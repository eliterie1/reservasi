<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>@yield('title', 'BreakPoint Billiard')</title>
  <meta name="description" content="Reservasi meja biliar multi-cabang. Pilih cabang dan jadwal, bayar di lokasi.">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>body{font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}.brand{color:#173f35}.bg-brand{background:#173f35}</style>
</head>
<body class="min-h-screen bg-white text-slate-900">
<header class="border-b border-slate-100 bg-white">
  <div class="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
    <a href="{{ route('home') }}" class="flex items-center gap-3">
      <span class="flex h-10 w-10 items-center justify-center rounded-xl bg-brand text-white font-bold">B</span>
      <span><span class="block font-extrabold tracking-tight brand">BREAKPOINT</span><span class="block text-[10px] tracking-[.24em] text-slate-500">BILLIARD CLUB</span></span>
    </a>
    <nav class="flex items-center gap-4 text-sm">
      <a class="hidden text-slate-600 hover:text-slate-950 sm:inline" href="{{ route('booking.create') }}">Reservasi</a>
      @auth
        <a class="font-semibold brand" href="{{ route('admin.index') }}">Dashboard</a>
        <form action="{{ route('logout') }}" method="POST">@csrf<button class="text-slate-500">Keluar</button></form>
      @else
        <a class="rounded-lg border border-slate-200 px-3 py-2 font-medium hover:bg-slate-50" href="{{ route('login') }}">Admin</a>
      @endauth
    </nav>
  </div>
</header>
@if(session('success'))
<div class="mx-auto mt-4 max-w-6xl px-4"><div class="rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-800">{{ session('success') }}</div></div>
@endif
@if($errors->any())
<div class="mx-auto mt-4 max-w-6xl px-4"><div class="rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-800"><p class="mb-1 font-semibold">Periksa kembali:</p><ul class="list-disc pl-5">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div></div>
@endif
<main>@yield('content')</main>
<footer class="mt-16 border-t border-slate-100"><div class="mx-auto flex max-w-6xl flex-col gap-2 px-4 py-8 text-xs text-slate-500 sm:flex-row sm:justify-between"><span>© {{ date('Y') }} BreakPoint Billiard</span><span>Reservasi online · Pembayaran di lokasi</span></div></footer>
</body>
</html>
