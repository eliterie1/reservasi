## Scope and known limitations

- Starter MVP, not yet a fully audited production system.
- Public reservation confirmation pages use a hard-to-guess code; for a public deployment consider adding phone OTP or signed expiring URLs before exposing customer details.
- Customer-facing availability is checked authoritatively on submission; the starter form does not yet provide live per-time availability.
- Admin user creation command supports owner role. Staff account/role management UI is not included yet.
- Reservations use a single table per booking. Multi-table packages and events can be added later.
- Business rules assume same-day operating hours and do not support a session that crosses midnight.
- Tailwind CDN is used for fast MVP UI. For production, compile Tailwind locally and pin dependencies.
- A payment is recorded as paid in the reservation record for this starter. For audit-ready accounting, add a separate immutable payments ledger with method, amount, cashier, and timestamps.
- Run tests after adding any production-specific configuration.
