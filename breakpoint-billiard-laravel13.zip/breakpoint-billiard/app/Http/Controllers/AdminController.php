<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Models\BilliardTable;
use App\Models\Reservation;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class AdminController extends Controller
{
    private function scopedReservations()
    {
        $q = Reservation::with(['branch', 'table', 'customer'])->latest('starts_at');
        if (!auth()->user()->isOwner()) $q->where('branch_id', auth()->user()->branch_id);
        return $q;
    }

    private function scopedTables()
    {
        $q = BilliardTable::with('branch')->orderBy('branch_id')->orderBy('name');
        if (!auth()->user()->isOwner()) $q->where('branch_id', auth()->user()->branch_id);
        return $q;
    }

    public function index()
    {
        $branchQuery = Branch::query();
        if (!auth()->user()->isOwner()) $branchQuery->whereKey(auth()->user()->branch_id);
        $branches = $branchQuery->withCount('tables')->get();
        $reservations = $this->scopedReservations()->whereDate('starts_at', today())->get();
        $stats = [
            'today' => $reservations->count(),
            'unpaid' => $reservations->where('payment_status', 'unpaid')->sum('total_amount'),
            'playing' => $reservations->where('status', 'checked_in')->count(),
        ];
        return view('admin.index', compact('branches', 'reservations', 'stats'));
    }

    public function reservations()
    {
        $reservations = $this->scopedReservations()->paginate(30);
        return view('admin.reservations', compact('reservations'));
    }

    public function cancel(Reservation $reservation)
    {
        $this->authorizeBranch($reservation->branch_id);
        if ($reservation->payment_status === 'paid') {
            throw ValidationException::withMessages(['reservation' => 'Reservasi yang sudah dibayar perlu proses refund manual sebelum dibatalkan.']);
        }
        $reservation->update(['status' => 'cancelled', 'cancelled_at' => now()]);
        return back()->with('success', 'Reservasi dibatalkan.');
    }

    public function checkIn(Reservation $reservation)
    {
        $this->authorizeBranch($reservation->branch_id);
        if ($reservation->status !== 'confirmed') throw ValidationException::withMessages(['reservation' => 'Hanya reservasi terkonfirmasi yang bisa check-in.']);
        $reservation->update(['status' => 'checked_in', 'checked_in_at' => now()]);
        return back()->with('success', 'Pelanggan berhasil check-in.');
    }

    public function markPaid(Reservation $reservation)
    {
        $this->authorizeBranch($reservation->branch_id);
        if ($reservation->status === 'cancelled') throw ValidationException::withMessages(['reservation' => 'Reservasi batal tidak bisa ditandai lunas.']);
        $reservation->update(['payment_status' => 'paid']);
        return back()->with('success', 'Pembayaran dicatat lunas.');
    }

    public function tables()
    {
        $tables = $this->scopedTables()->paginate(50);
        $branches = Branch::where('is_active', true)->get();
        return view('admin.tables', compact('tables', 'branches'));
    }

    public function updateTable(Request $request, BilliardTable $table)
    {
        $this->authorizeBranch($table->branch_id);
        $data = $request->validate([
            'hourly_rate' => ['required', 'integer', 'min:0', 'max:10000000'],
            'is_active' => ['required', 'boolean'],
            'table_type' => ['required', 'string', 'max:80'],
        ]);
        $table->update($data);
        return back()->with('success', 'Tarif dan data meja diperbarui.');
    }

    public function branches()
    {
        abort_unless(auth()->user()->isOwner(), 403);
        $branches = Branch::withCount('tables')->orderBy('name')->get();
        return view('admin.branches', compact('branches'));
    }

    public function storeBranch(Request $request)
    {
        abort_unless(auth()->user()->isOwner(), 403);
        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'address' => ['required', 'string', 'max:255'],
            'phone' => ['nullable', 'string', 'max:30'],
            'opens_at' => ['required', 'date_format:H:i'],
            'closes_at' => ['required', 'date_format:H:i', 'after:opens_at'],
        ]);
        $branch = Branch::create($data + ['slug' => Str::slug($data['name']).'-'.Str::lower(Str::random(4)), 'is_active' => true]);
        for ($i = 1; $i <= 9; $i++) {
            $branch->tables()->create(['name' => 'Meja '.str_pad((string)$i, 2, '0', STR_PAD_LEFT), 'table_type' => 'Standard', 'hourly_rate' => 50000, 'is_active' => true]);
        }
        return back()->with('success', 'Cabang dibuat dengan 9 meja. Tarif dapat diubah dari menu Meja & Tarif.');
    }

    private function authorizeBranch(int $branchId): void
    {
        abort_unless(auth()->user()->isOwner() || auth()->user()->branch_id === $branchId, 403);
    }
}
