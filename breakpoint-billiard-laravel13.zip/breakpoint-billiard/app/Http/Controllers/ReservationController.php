<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Models\BilliardTable;
use App\Models\Customer;
use App\Models\Reservation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Carbon\Carbon;

class ReservationController extends Controller
{
    public function index()
    {
        $branches = Branch::where('is_active', true)->withCount('tables')->orderBy('name')->get();
        return view('home', compact('branches'));
    }

    public function create(Request $request)
    {
        $branches = Branch::where('is_active', true)->orderBy('name')->get();
        $branchId = $request->integer('branch_id') ?: optional($branches->first())->id;
        $branch = $branches->firstWhere('id', $branchId);
        $tables = $branch ? $branch->tables()->where('is_active', true)->orderBy('name')->get() : collect();
        return view('booking.create', compact('branches', 'branch', 'tables'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'branch_id' => ['required', 'integer', 'exists:branches,id'],
            'table_id' => ['required', 'integer', 'exists:billiard_tables,id'],
            'customer_name' => ['required', 'string', 'max:120'],
            'customer_phone' => ['required', 'string', 'max:30'],
            'customer_email' => ['nullable', 'email', 'max:190'],
            'date' => ['required', 'date', 'after_or_equal:today'],
            'start_time' => ['required', 'date_format:H:i'],
            'duration_minutes' => ['required', 'integer', 'in:60,120,180,240'],
            'notes' => ['nullable', 'string', 'max:500'],
        ]);

        $branch = Branch::where('is_active', true)->findOrFail($data['branch_id']);
        $start = Carbon::parse($data['date'].' '.$data['start_time'], 'Asia/Jakarta');
        $end = $start->copy()->addMinutes((int) $data['duration_minutes']);

        if ($start->isPast()) {
            throw ValidationException::withMessages(['start_time' => 'Waktu mulai harus di masa depan.']);
        }
        if ($start->minute !== 0 && $start->minute !== 30) {
            throw ValidationException::withMessages(['start_time' => 'Pilih jam mulai pada menit 00 atau 30.']);
        }
        if ($start->format('H:i') < substr((string) $branch->opens_at, 0, 5) || $end->format('H:i') > substr((string) $branch->closes_at, 0, 5) || $end->toDateString() !== $start->toDateString()) {
            throw ValidationException::withMessages(['start_time' => 'Jadwal harus berada dalam jam operasional cabang dan tidak melewati tengah malam.']);
        }

        $reservation = DB::transaction(function () use ($data, $branch, $start, $end) {
            $table = BilliardTable::where('branch_id', $branch->id)
                ->where('is_active', true)
                ->whereKey($data['table_id'])
                ->lockForUpdate()
                ->first();

            if (!$table) {
                throw ValidationException::withMessages(['table_id' => 'Meja tidak tersedia di cabang tersebut.']);
            }

            $overlap = Reservation::query()->blocking()
                ->where('table_id', $table->id)
                ->where('starts_at', '<', $end)
                ->where('ends_at', '>', $start)
                ->exists();

            if ($overlap) {
                throw ValidationException::withMessages(['table_id' => 'Jadwal ini baru saja dipesan. Silakan pilih meja atau waktu lain.']);
            }

            $customer = Customer::firstOrCreate(
                ['phone' => $data['customer_phone']],
                ['name' => $data['customer_name'], 'email' => $data['customer_email'] ?? null]
            );
            $customer->update(['name' => $data['customer_name'], 'email' => $data['customer_email'] ?? $customer->email]);

            $hours = $data['duration_minutes'] / 60;
            return Reservation::create([
                'code' => 'BP-'.now()->format('ymd').'-'.Str::upper(Str::random(6)),
                'branch_id' => $branch->id,
                'table_id' => $table->id,
                'customer_id' => $customer->id,
                'starts_at' => $start,
                'ends_at' => $end,
                'duration_minutes' => $data['duration_minutes'],
                'hourly_rate' => $table->hourly_rate,
                'total_amount' => (int) ($table->hourly_rate * $hours),
                'status' => 'confirmed',
                'payment_status' => 'unpaid',
                'notes' => $data['notes'] ?? null,
            ]);
        }, 3);

        return redirect()->route('booking.show', $reservation->code)->with('success', 'Reservasi berhasil dikonfirmasi. Pembayaran dilakukan di lokasi.');
    }

    public function show(string $code)
    {
        $reservation = Reservation::with(['branch', 'table', 'customer'])->where('code', $code)->firstOrFail();
        return view('booking.show', compact('reservation'));
    }
}
