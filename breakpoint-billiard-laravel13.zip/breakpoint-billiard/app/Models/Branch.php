<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Branch extends Model
{
    protected $fillable = ['name', 'slug', 'address', 'phone', 'opens_at', 'closes_at', 'is_active'];
    protected function casts(): array { return ['is_active' => 'boolean']; }
    public function tables() { return $this->hasMany(BilliardTable::class); }
    public function reservations() { return $this->hasMany(Reservation::class); }
    public function users() { return $this->hasMany(User::class); }
}
