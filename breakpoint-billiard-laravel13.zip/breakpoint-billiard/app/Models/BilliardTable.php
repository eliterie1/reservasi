<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BilliardTable extends Model
{
    protected $table = 'billiard_tables';
    protected $fillable = ['branch_id', 'name', 'table_type', 'hourly_rate', 'is_active', 'notes'];
    protected function casts(): array { return ['hourly_rate' => 'integer', 'is_active' => 'boolean']; }
    public function branch() { return $this->belongsTo(Branch::class); }
    public function reservations() { return $this->hasMany(Reservation::class, 'table_id'); }
}
