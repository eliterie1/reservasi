<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Reservation extends Model
{
    protected $fillable = ['code', 'branch_id', 'table_id', 'customer_id', 'starts_at', 'ends_at', 'duration_minutes', 'hourly_rate', 'total_amount', 'status', 'payment_status', 'notes', 'checked_in_at', 'cancelled_at'];
    protected function casts(): array {
        return ['starts_at' => 'datetime', 'ends_at' => 'datetime', 'checked_in_at' => 'datetime', 'cancelled_at' => 'datetime', 'hourly_rate' => 'integer', 'total_amount' => 'integer'];
    }
    public function branch() { return $this->belongsTo(Branch::class); }
    public function table() { return $this->belongsTo(BilliardTable::class, 'table_id'); }
    public function customer() { return $this->belongsTo(Customer::class); }
    public function scopeBlocking($query) { return $query->whereIn('status', ['confirmed', 'checked_in']); }
}
