# BreakPoint Billiard — Laravel 13 + PostgreSQL

Starter project untuk reservasi biliar multi-cabang:
- Portal reservasi pelanggan, booking langsung terkonfirmasi, pembayaran di lokasi.
- Dashboard admin untuk cabang, meja, reservasi, tarif, dan pencatatan pembayaran.
- 9 meja awal per cabang, tarif default Rp50.000/jam, interval booking 60 menit.
- PostgreSQL, Docker Compose, dan deployment pada VM Ubuntu di Proxmox.

> Ini adalah starter code yang perlu diuji di lingkungan Anda sebelum dipakai untuk transaksi nyata. ZIP ini tidak menyertakan `vendor/` atau hasil build frontend.

## 1. Prasyarat VM Ubuntu
Disarankan mulai dari VM Ubuntu Server dengan 2 vCPU, RAM 4 GB, disk 40 GB, serta akses internet untuk menarik image Docker. Pastikan port 8080 VM dapat diakses dari jaringan admin.

Pasang Docker Engine dan plugin Compose dari dokumentasi resmi Docker:
https://docs.docker.com/engine/install/ubuntu/

## 2. Jalankan
```bash
unzip breakpoint-billiard.zip
cd breakpoint-billiard
cp .env.example .env
# Ganti password DB di .env sebelum menjalankan layanan.
docker compose up -d --build
docker compose exec app php artisan key:generate
docker compose exec app php artisan migrate --seed
```

Buka `http://IP-VM:8080`.

Untuk membuat akun admin awal:
```bash
docker compose exec app php artisan make:admin admin@example.com
```
Command tersebut meminta password secara interaktif. Ganti email sesuai kebutuhan.

## 3. Cara kerja booking
- Pelanggan memilih cabang, meja, tanggal/jam mulai, dan durasi dalam kelipatan 60 menit.
- Reservasi dikonfirmasi langsung dan dibayar di lokasi.
- Server memvalidasi jam operasional, durasi, cabang, dan bentrok jadwal.
- Saat transaksi dibuat, baris meja dikunci (`FOR UPDATE`) dalam transaksi PostgreSQL sebelum pengecekan bentrok untuk mengurangi risiko dua booking bersamaan.
- Reservasi `confirmed` dan `checked_in` memblokir slot. Reservasi `cancelled` tidak memblokir slot.
- Tarif diambil dari tarif meja pada cabang tersebut. Admin dapat mengubah tarif tiap meja.

## 4. Catatan produksi
Sebelum internet-facing production:
- Pasang domain dan HTTPS pada reverse proxy.
- Jangan expose port PostgreSQL (container DB tidak dipublikasikan ke host).
- Ganti seluruh password default.
- Konfigurasi backup PostgreSQL off-host dan uji restore.
- Tambahkan rate limit, verifikasi nomor HP, kebijakan pembatalan/no-show, dan audit log yang lebih lengkap.
- Review keamanan, pengujian otomatis, serta kebijakan privasi sebelum menerima pelanggan.
