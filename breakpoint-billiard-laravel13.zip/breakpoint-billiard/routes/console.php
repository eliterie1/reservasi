<?php

use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

Artisan::command('make:admin {email}', function (string $email) {
    $password = $this->secret('Set password (minimum 12 characters)');
    if (!$password || strlen($password) < 12) {
        $this->error('Password must be at least 12 characters.');
        return 1;
    }
    $user = User::updateOrCreate(['email' => $email], [
        'name' => 'Administrator',
        'password' => Hash::make($password),
        'role' => 'owner',
        'branch_id' => null,
        'email_verified_at' => now(),
    ]);
    $this->info("Admin account ready: {$user->email}");
})->purpose('Create or update an owner account');
