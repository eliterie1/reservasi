<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ReservationController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\AuthController;

Route::get('/', [ReservationController::class, 'index'])->name('home');
Route::get('/booking', [ReservationController::class, 'create'])->name('booking.create');
Route::post('/booking', [ReservationController::class, 'store'])->middleware('throttle:10,1')->name('booking.store');
Route::get('/booking/{code}', [ReservationController::class, 'show'])->name('booking.show');

Route::get('/login', [AuthController::class, 'show'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:5,1')->name('login.store');
Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

Route::middleware(['auth'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/', [AdminController::class, 'index'])->name('index');
    Route::get('/reservations', [AdminController::class, 'reservations'])->name('reservations');
    Route::post('/reservations/{reservation}/cancel', [AdminController::class, 'cancel'])->name('reservations.cancel');
    Route::post('/reservations/{reservation}/check-in', [AdminController::class, 'checkIn'])->name('reservations.checkin');
    Route::post('/reservations/{reservation}/paid', [AdminController::class, 'markPaid'])->name('reservations.paid');
    Route::get('/tables', [AdminController::class, 'tables'])->name('tables');
    Route::patch('/tables/{table}', [AdminController::class, 'updateTable'])->name('tables.update');
    Route::get('/branches', [AdminController::class, 'branches'])->name('branches');
    Route::post('/branches', [AdminController::class, 'storeBranch'])->name('branches.store');
});
