<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Branch;
use App\Models\BilliardTable;
use App\Models\Customer;
use App\Models\Reservation;
use Illuminate\Foundation\Testing\RefreshDatabase;

class ReservationValidationTest extends TestCase
{
    use RefreshDatabase;

    public function test_overlapping_reservation_is_rejected(): void
    {
        $branch = Branch::create(['name'=>'Test','slug'=>'test','address'=>'Test address','opens_at'=>'10:00','closes_at'=>'23:00','is_active'=>true]);
        $table = BilliardTable::create(['branch_id'=>$branch->id,'name'=>'Meja 01','table_type'=>'Standard','hourly_rate'=>50000,'is_active'=>true]);
        $customer = Customer::create(['name'=>'Test Customer','phone'=>'08123456789']);
        Reservation::create([
            'code'=>'BP-TEST-000001','branch_id'=>$branch->id,'table_id'=>$table->id,'customer_id'=>$customer->id,
            'starts_at'=>'2030-01-10 12:00:00+07','ends_at'=>'2030-01-10 13:00:00+07','duration_minutes'=>60,
            'hourly_rate'=>50000,'total_amount'=>50000,'status'=>'confirmed','payment_status'=>'unpaid'
        ]);
        $this->from('/booking')->post('/booking', [
            'branch_id'=>$branch->id,'table_id'=>$table->id,'customer_name'=>'Another','customer_phone'=>'081111111111',
            'date'=>'2030-01-10','start_time'=>'12:00','duration_minutes'=>60
        ])->assertSessionHasErrors('table_id');
    }
}
